from django.contrib import admin
from .models import uploadFiles
# Register your models here.
admin.site.register(uploadFiles)